package test;

public class byteexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
