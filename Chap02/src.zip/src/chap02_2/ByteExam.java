package chap02_2;

public class ByteExam {

	public static void main(String[] args) {
		byte byte1 = -128;
		byte byte2 = 127;
//		byte byte3 = 128; ������ ����
		System.out.println(byte1);
		System.out.println(byte2);
		

	}

}
