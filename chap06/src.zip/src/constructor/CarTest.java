package constructor;

import constructor.ThisThis;

public class CarTest {

	public static void main(String[] args) {
		Car car0 = new Car();
//		Car car1 = new Car("�׷���", "����", 250);
//		System.out.println(car1.model);
//		Car car2 = new Car("���׽ý�", "���", 250);
//		System.out.println( car2.model);
//		Car car3 = new Car("sm7", "�Ķ�", 300);
//
//		
//		Car car4 = new Car();
//		System.out.println( car4.model);
//		
//		Car car5 = new Car("�����");
//		System.out.println(car5.model);
//		
//		Car car6 = new Car(299792);
//		System.out.println(car6.maxSpeed);
	}

}
