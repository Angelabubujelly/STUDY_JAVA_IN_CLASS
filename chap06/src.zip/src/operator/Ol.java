package operator;

public class Ol {
	String name;
	int month;
	int num1 =1;
	int num2 = 1;
	
	Ol(){
		this("���߰�",2);
	}
	Ol (String name){
		this(name,2);
	}
	Ol(String name, int month)	{
		this.name = name;
		this.month = month;
	}
	


}