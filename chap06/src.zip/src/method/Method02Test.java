package method;

public class Method02Test {

	public static void main(String[] args) {
		 Method02 me02 = new Method02(); //method02 Ŭ���� ��ü�� ������.
		 me02.add(5, 7);
		 
		 System.out.println(me02.add(5,7));
		 System.out.println(me02.add(50, 80));
		 System.out.println();// println��ü�� �޼ҵ巩;
		 System.out.println(me02.subtract(52, 0));
		 System.out.println(me02.multifly(1, 2));
		 System.out.println(me02.divide(9,9));
		 


	}

}
	